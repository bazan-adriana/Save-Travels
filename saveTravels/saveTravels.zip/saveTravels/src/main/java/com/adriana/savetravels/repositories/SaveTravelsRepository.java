package com.adriana.savetravels.repositories;

import org.springframework.data.repository.CrudRepository;

import com.adriana.savetravels.models.SaveTravels;

public interface SaveTravelsRepository extends CrudRepository<SaveTravels, Long> {

}
